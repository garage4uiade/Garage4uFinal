package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class controlo extends AppCompatActivity {

    Button button_luz;
    Button button_porta1;
    Button button_porta2;
    public ArrayList<ArrayList<String>> dados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controlo);

        Intent getIntent = getIntent();
        dados =(ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
        button_luz = (Button) findViewById(R.id.button_luz);
        button_porta1 = (Button) findViewById(R.id.button_porta1);
        button_porta2 = (Button) findViewById(R.id.button_porta2);
        comando_luz();

    }

    public void comando_luz() {
        button_luz.setVisibility(View.VISIBLE);
        button_porta1.setVisibility(View.VISIBLE);
        button_porta2.setVisibility(View.INVISIBLE);
    }

    public void comando_sem_luz() {
        button_luz.setVisibility(View.INVISIBLE);
        button_porta1.setVisibility(View.INVISIBLE);
        button_porta2.setVisibility(View.VISIBLE);
    }

    public void click_voltar(View v) {
        Intent mainActivity=new Intent();
        String windows = dados.get(1).get(dados.get(1).size()-1);

        switch (windows){
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(),cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
        }
        dados.get(1).remove(dados.get(1).size()-1);
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }


}