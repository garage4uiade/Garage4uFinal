package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.JSONarrayDownloader;

public class carteira extends AppCompatActivity {

    public ArrayList<ArrayList<String>> dados;
    EditText a1;
    EditText a2;
    EditText a3;
    EditText a4;
    RadioButton r1;
    RadioButton r2;
    public JSONArray utiObj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carteira);

        Intent getIntent = getIntent();
        dados =(ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
        String email=dados.get(0).get(0);
        String pass=dados.get(0).get(2);
        a1=findViewById(R.id.cartao_nome);
        a2=findViewById(R.id.cartao_num);
        a3=findViewById(R.id.cartao_cvv);
        a4=findViewById(R.id.creditos_util);
        r1=findViewById(R.id.radioButton);
        r2=findViewById(R.id.radioButton2);



        JSONarrayDownloader obj = new JSONarrayDownloader();
        JSONObject utiObj2;
        ArrayList utilizador = new ArrayList();

        try {
            utiObj = obj.execute("https://garage4u-bd.herokuapp.com/api/querys/utilizador_info/"+email+"/"+pass).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }
        if (utiObj != null) {
            try {
                utiObj2 = utiObj.getJSONObject(0);
                utilizador.add(utiObj2.getString("nomeCartao"));
                utilizador.add(utiObj2.getString("numCartao"));
                utilizador.add(utiObj2.getString("cvv"));
                utilizador.add(utiObj2.getString("quantidadeDinheiro"));

                utilizador.add("false");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            a1.setText(utilizador.get(0).toString());
            a2.setText(utilizador.get(1).toString());
            a3.setText(utilizador.get(2).toString());
            a4.setText(utilizador.get(3).toString());
            if(utilizador.get(2).toString().equals("false"))
            {
                r1.setChecked(true);
                r2.setChecked(false);
            }
            else
            {
                r1.setChecked(false);
                r2.setChecked(true);
            }
        }
    }

    public void click_voltar(View v) {
        Intent mainActivity = new Intent();
        String windows = dados.get(1).get(dados.get(1).size() - 1);

        switch (windows) {
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(), cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
        }
        dados.get(1).remove(dados.get(1).size() - 1);
        mainActivity.putExtra("dados", dados);
        startActivity(mainActivity);
    }
}