package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.JSONarrayDownloader;
import pt.iade.garage4u.Downloader.JSONobjDownloader;

public class reserva_garagens extends AppCompatActivity {

    public JSONObject utiObj;
    public ArrayList<ArrayList<String>> dados;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reserva_garagens);
        Intent getIntent = getIntent();
        dados = (ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
        JSONobjDownloader downloa = new JSONobjDownloader();
        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/garagens/" + dados.get(2).get(0).toString()).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }
        if (utiObj != null) {
            try {
                String localizacaorua = utiObj.getString("localizacaoRua");
                String localizacaogeo = utiObj.getString("localizacaoGeo");
                JSONObject Propriatario = utiObj.getJSONObject("idPropriatario");
                JSONObject Estado = utiObj.getJSONObject("idEstado");
                JSONObject Zona = utiObj.getJSONObject("idZona");

                Double geo1 = Double.parseDouble(localizacaogeo.substring(0, localizacaogeo.indexOf(",")));
                Double geo2 = Double.parseDouble(localizacaogeo.substring(localizacaogeo.indexOf(",") + 2));

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        //GET http://localhost:8082/api/querys/garagens_info/1
    }
}