package pt.iade.garage4u;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.JSONarrayDownloader;
import pt.iade.garage4u.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements GoogleMap.OnMarkerClickListener,OnMapReadyCallback {

    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    TextView t1;

    String id="";
    List<String>garagens_info;

    boolean click=true;
    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    public JSONArray utiObj;
    public ArrayList<ArrayList<String>> dados;
    private Marker garagens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        button1 = (Button) findViewById(R.id.button3);
        button3 = (Button) findViewById(R.id.button4);
        button4 = (Button) findViewById(R.id.button5);
        button2 = (Button) findViewById(R.id.button6);
        button5 = (Button) findViewById(R.id.button7);
        t1 = findViewById(R.id.editTextTextPersonName2);

        click = false;
        mapFragment.getMapAsync(this);
        Intent getIntent = getIntent();
        dados =(ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
        button1.setVisibility(View.INVISIBLE);
        button2.setVisibility(View.INVISIBLE);
        button3.setVisibility(View.INVISIBLE);
        button4.setVisibility(View.INVISIBLE);
        button5.setVisibility(View.INVISIBLE);
        t1.setVisibility(View.INVISIBLE);
        //button1.setVisibility(View.VISIBLE);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng sydney;
        JSONarrayDownloader downloa = new JSONarrayDownloader();
        JSONObject obj;
        garagens_info= new ArrayList();
        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/garagens").get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }
        List<String> garagens_pos= new ArrayList();
        if (utiObj != null) {
            try {
                for (int num=0;utiObj.length()>num;num++) {
                    obj = utiObj.getJSONObject(num);
                    garagens_pos.add(obj.getString("localizacaoRua"));
                    String localizacaogeo = obj.getString("localizacaoGeo");
                    JSONObject Propriatario = obj.getJSONObject("idPropriatario");
                    JSONObject Estado = obj.getJSONObject("idEstado");
                    JSONObject Zona = obj.getJSONObject("idZona");
                    garagens_pos.add(obj.getString("garagensId"));

                    Double geo1 = Double.parseDouble(localizacaogeo.substring(0,localizacaogeo.indexOf(",")));
                    Double geo2 = Double.parseDouble(localizacaogeo.substring(localizacaogeo.indexOf(",")+2));

                    sydney = new LatLng(geo1, geo2);
                    garagens = mMap.addMarker(new MarkerOptions().position(sydney).title(Zona.getString("nomeZona")));
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
                    garagens.setTag(garagens_pos);;
                }
            } catch (JSONException e) {e.printStackTrace();}
        }
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(38.707108,-9.152529), 12));
        mMap.setOnMarkerClickListener(this);
    }

    @Override
    public boolean onMarkerClick(final Marker marker) {

        // Retrieve the data from the marker.
        garagens_info = (List<String>) marker.getTag();
        button5.setVisibility(View.VISIBLE);
        t1.setVisibility(View.VISIBLE);
        t1.setText(garagens_info.get(0).toString());

        return false;
    }

    public void click_reservas(View v) {
        ArrayList garagem = new ArrayList();
        garagem.add(garagens_info.get(1).toString());
        dados.get(1).add("maps");
        dados.add(garagem);
        Intent mainActivity = new Intent(getApplicationContext(), reserva_garagens.class);
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }

    public void click_info(View v) {
        dados.get(1).add("maps");
        Intent mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }

    public void click_voltar(View v) {
        Intent mainActivity;
        String intent = dados.get(1).get(dados.get(1).size());

        switch (intent){
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(),cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
            case "Reservas":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "carteira":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "esqueci":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "Reserva":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
        }

        mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
        dados.get(1).remove(dados.get(1).size());
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }

    public void click_menu(View v) {
        if(click == false){
            button1.setVisibility(View.INVISIBLE);
            button2.setVisibility(View.INVISIBLE);
            button3.setVisibility(View.INVISIBLE);
            button4.setVisibility(View.INVISIBLE);
            click = true;
        }
        else{
            button1.setVisibility(View.VISIBLE);
            button2.setVisibility(View.VISIBLE);
            button3.setVisibility(View.INVISIBLE);
            button4.setVisibility(View.INVISIBLE);
            click = false;
        }

    }

    public void click_controlo(View v) {
        dados.get(1).add("maps");
        Intent mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }
}