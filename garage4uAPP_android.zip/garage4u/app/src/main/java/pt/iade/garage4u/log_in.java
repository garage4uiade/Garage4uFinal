package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.JSONarrayDownloader;
import pt.iade.garage4u.Downloader.JSONobjDownloader;

public class log_in extends AppCompatActivity {

    EditText a1;
    EditText a2;
    boolean erro;

    public ArrayList<ArrayList<String>> dados;
    public ArrayList<String> util;
    public ArrayList<String> caminho;
    public ArrayAdapter<String> adapterRoutes;
    public JSONObject utiObj;
    public JSONArray utiObj2;
    public JSONArray utiObj3;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        a1=findViewById(R.id.txt_email);
        a2=findViewById(R.id.txt_pass);
        Intent getIntent = getIntent();
        erro = getIntent.getBooleanExtra("erro",false);
        a1.setText("brunomarcospreto1998@gmail.com");
        a2.setText("123456789");
    }

    public void on_click(View v) throws JSONException {

        String texto[] = new String[2];
        texto[0] = a1.getText().toString();
        texto[1] = a2.getText().toString();

        JSONarrayDownloader obj2 = new JSONarrayDownloader();
        JSONarrayDownloader obj3 = new JSONarrayDownloader();
        JSONobjDownloader obj = new JSONobjDownloader();
        ArrayList caminho = new ArrayList();
        ArrayList dados = new ArrayList();
        ArrayList util = new ArrayList();
        try {
            utiObj2 = obj2.execute("https://garage4u-bd.herokuapp.com/api/querys/existe/"+a1.getText().toString()+"/"+a2.getText().toString()).get();

        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj2 = null;
        }
        if (utiObj2 != null) {
            String t = utiObj2.getString(0);


            if(t.equals("nao existe"))
            {
                Toast.makeText(getApplicationContext(),"utilizador nao existe",Toast.LENGTH_SHORT).show();
            }
            else
            {
                if(t.equals("existe mas a palavra pass esta errada "))
                {
                    Toast.makeText(getApplicationContext(),"utilizador existe mas a palavra pass esta errada",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    try {
                        //utiObj = obj.execute("https://garage4u-bd.herokuapp.com/api/querys/utilizador_info/"+a1.getText().toString()+"/"+a2.getText().toString()).get();
                        utiObj3 = obj3.execute("https://garage4u-bd.herokuapp.com/api/querys/utilizador_info/"+a1.getText().toString()+"/"+a2.getText().toString()).get();
                    } catch (ExecutionException | InterruptedException e) {
                        e.printStackTrace();
                        utiObj = null;
                        utiObj3 = null;
                    }
                    if (utiObj3 != null) {
                        try {
                            utiObj = utiObj3.getJSONObject(0);
                            util.add(utiObj.getString("utilizadorEmail"));
                            util.add(utiObj.getString("utilizadorName"));
                            util.add(utiObj.getString("utilizadorPass"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        dados.add(util);
                        caminho.add("login");
                        dados.add(caminho);
                        Intent mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                        mainActivity.putExtra("dados",dados);
                        startActivity(mainActivity);
                    }
                }
            }
        }
    }

    public void esqueci(View v) {


        String texto [] = new String[2];
        texto[0] = a1.getText().toString();
        texto[1] = a2.getText().toString();
        Intent mainActivity = new Intent(getApplicationContext(), esquecime_da_palavrapass.class);
        mainActivity.putExtra("dados",texto);
        startActivity(mainActivity);
    }
    public void cadastrar(View v) {


        String texto [] = new String[2];
        texto[0] = a1.getText().toString();
        texto[1] = a2.getText().toString();
        Intent mainActivity = new Intent(getApplicationContext(), cadastro.class);
        startActivity(mainActivity);
    }
}