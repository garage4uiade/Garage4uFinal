package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.GetPerson;
import pt.iade.garage4u.Downloader.JSONarrayDownloader;
import pt.iade.garage4u.Downloader.PostData;

public class adicionar_garagens extends AppCompatActivity {

    public ArrayList<ArrayList<String>> dados;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar_garagens);
        Intent getIntent = getIntent();
        dados =(ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
    }

    public void onClick(View view) {
        GetPerson getPerson = new GetPerson();
        Intent i = new Intent(getApplicationContext(), log_in.class);
        try {
            String lampada="false";

            /*
            if (r1.isChecked()) {

            } else {

            }
             */

            JSONarrayDownloader obj = new JSONarrayDownloader();
            JSONArray utiObj;
            String idutilizador ="";
            try {
                utiObj = obj.execute("https://mint-bd.herokuapp.com/api/querys/existe/" + dados.get(0).get(0) + "/" + dados.get(0).get(2)).get();

            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
                utiObj = null;
            }
            if (utiObj != null) {
                idutilizador = utiObj.toString();
                idutilizador = idutilizador.substring(2, idutilizador.length() - 2);

            }

            /*
            try {
                utiObj = obj.execute("https://mint-bd.herokuapp.com/api/querys/existe/" + texto[0] + "/" + texto[1]).get();

            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
                utiObj = null;
            }
            if (utiObj != null) {
                idutilizador = utiObj.toString();
                idutilizador = idutilizador.substring(2, idutilizador.length() - 2);

            }

             */

            // reserva garagens reserva, resgar
            // adicionar rate apos terminar a reserva




            Map<String, String> postData = new HashMap<>();
            postData.put("lampada",lampada);
            postData.put("idZona","");
            postData.put("idEstado","1");
            postData.put("idPropriatario",idutilizador);
            postData.put("localizacaoGeo","");
            postData.put("localizacaoRua","");


            PostData task = new PostData(postData);
            task.execute("https://garage4u-bd.herokuapp.com/api/garagens");


            Toast.makeText(getApplicationContext(), "Utilizador criado com sucesso", Toast.LENGTH_SHORT).show();
            Log.e("Signup", "" + postData.toString());
            startActivity(i);
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    public void click_voltar(View v) {
        Intent mainActivity = new Intent();
        String windows = dados.get(1).get(dados.get(1).size() - 1);

        switch (windows){
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(),cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
            case "Reservas":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "carteira":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "esqueci":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "Reserva":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
        }
        dados.get(1).remove(dados.get(1).size() - 1);
        mainActivity.putExtra("dados", dados);
        startActivity(mainActivity);
    }

}