package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.JSONarrayDownloader;

public class carteira extends AppCompatActivity {

    boolean click=false;
    boolean check=false;
    Button button;
    public ArrayList<ArrayList<String>> dados;
    EditText a1;
    EditText a2;
    EditText a3;
    EditText a4;
    EditText a5;
    RadioButton r1;
    RadioButton r2;
    public JSONArray utiObj;
    ArrayList utilizador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carteira);

        Intent getIntent = getIntent();
        dados =(ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
        button = (Button) findViewById(R.id.RegButton2);

        a1=findViewById(R.id.cartao_nome);
        a2=findViewById(R.id.cartao_num);
        a3=findViewById(R.id.cartao_cvv);
        a4=findViewById(R.id.creditos_util);
        a5=findViewById(R.id.Qtd_dinheiro);
        a1.setEnabled(false);
        a2.setEnabled(false);
        a3.setEnabled(false);
        a4.setEnabled(false);
        r1=findViewById(R.id.radioButton);
        r2=findViewById(R.id.radioButton2);
        r1.setEnabled(false);
        r2.setEnabled(false);

        atualizar();




    }

    public void atualizar(){
        String email=dados.get(0).get(0);
        String pass=dados.get(0).get(2);
        JSONarrayDownloader obj = new JSONarrayDownloader();
        JSONObject utiObj2;
        utilizador = new ArrayList();
        try {
            utiObj = obj.execute("https://garage4u-bd.herokuapp.com/api/querys/utilizador_info/"+email+"/"+pass).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }
        if (utiObj != null) {
            try {
                utiObj2 = utiObj.getJSONObject(0);
                utilizador.add(utiObj2.getString("nomeCartao"));
                utilizador.add(utiObj2.getString("numCartao"));
                utilizador.add(utiObj2.getString("cvv"));
                utilizador.add(utiObj2.getString("quantidadeDinheiro"));
                utilizador.add(utiObj2.getString("tipoDePagPerfCartao"));
                utilizador.add(utiObj2.getString("nomeCartao"));
                utilizador.add(utiObj2.getString("numCartao"));
                utilizador.add(utiObj2.getString("cvv"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            a1.setText(utilizador.get(0).toString());
            a2.setText(utilizador.get(1).toString());
            a3.setText(utilizador.get(2).toString());
            a4.setText(utilizador.get(3).toString());
            if(utilizador.get(4).toString().equals("false"))
            {
                check=false;
                r1.setChecked(true);
                r2.setChecked(false);
            }
            else
            {
                check=true;
                r1.setChecked(false);
                r2.setChecked(true);
            }
        }
    }

    public void click_voltar(View v) {
        Intent mainActivity = new Intent();
        String windows = dados.get(1).get(dados.get(1).size() - 1);

        switch (windows){
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(),cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
            case "Reservas":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "carteira":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "esqueci":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "Reserva":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
        }
        dados.get(1).remove(dados.get(1).size() - 1);
        mainActivity.putExtra("dados", dados);
        startActivity(mainActivity);
    }

    public void click_confirma_editar(View v) {

        if(click == false){
            button.setText("confirmar");
            a1.setEnabled(true);
            a2.setEnabled(true);
            a3.setEnabled(true);
            r1.setEnabled(true);
            r2.setEnabled(true);
            click = true;
        }
        else {
            boolean ativar;
            JSONArray utiObj;
            JSONarrayDownloader obj = new JSONarrayDownloader();
            JSONarrayDownloader obj2 = new JSONarrayDownloader();
            JSONObject utiObj2;

            String email=dados.get(0).get(0);
            String pass=dados.get(0).get(2);
            String cartao_nome=a1.getText().toString();
            String cartao_num=a2.getText().toString();
            String cartao_cvv=a3.getText().toString();
            if (r1.isChecked()) {
                if (check==true) {
                    ativar=true;
                }
                else {
                    ativar=false;
                }
            }
            else {
                if (check==true) {
                    ativar=false;
                }
                else {
                    ativar=true;
                }
            }




            if (ativar==true) {
            try {
                utiObj = obj.execute("https://garage4u-bd.herokuapp.com/api/querys/utilizador_tipo_de_pag_perf_cartao/" + email + "/" + pass).get();
            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
                utiObj = null;
            }
            /*
            if (utiObj != null) {
                try {
                    //utiObj2 = utiObj.getJSONObject(0);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

             */

            }

            try {
                utiObj = obj2.execute("https://garage4u-bd.herokuapp.com/api/querys/utilizador_update_cartao/" + email + "/" + pass+ "/" +cartao_num+ "/" +cartao_cvv+ "/" +cartao_nome).get();
            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
                utiObj = null;
            }
            /*
            if (utiObj != null) {
                try {
                    //utiObj2 = utiObj.getJSONObject(0);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

             */
        }
        atualizar();
    }

    public void click_levantar(View v) {
        JSONarrayDownloader downloa = new JSONarrayDownloader();
        JSONArray utiObj = new JSONArray();
        String controlo = "";

        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/confirma_trasacao/"+dados.get(0).get(0).toString()+"/"+dados.get(0).get(2).toString()+"/"+a5.getText().toString()).get();
        } catch (ExecutionException | InterruptedException e) { e.printStackTrace();       utiObj = null; }

        if (utiObj != null) {
            controlo = utiObj.toString();
            if(controlo.substring(2,controlo.length()-2).equals("tem"))
            {
                downloa = new JSONarrayDownloader();
                utiObj = new JSONArray();
                try {
                    utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/levantar/"+dados.get(0).get(0).toString()+"/"+dados.get(0).get(2).toString()+"/"+a5.getText().toString()).get();
                } catch (ExecutionException | InterruptedException e) {e.printStackTrace(); utiObj = null;}

                if (utiObj != null) {
                    controlo = utiObj.toString();
                    if(controlo.substring(2,controlo.length()-2).equals("levantado"))
                    {
                        downloa = new JSONarrayDownloader();
                        utiObj = new JSONArray();
                        try {
                            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/banco/depositar/"+utilizador.get(0).toString()+"/"+utilizador.get(1).toString()+"/"+utilizador.get(2).toString()+"/"+a5.getText().toString()).get();
                        } catch (ExecutionException | InterruptedException e) {e.printStackTrace(); }

                        if (utiObj != null) {
                            controlo = utiObj.toString();
                            if(controlo.substring(2,controlo.length()-2).equals("depositado"))
                            {
                                controlo="  levantado da sua conta  ";
                            }
                        }
                    }
                }
            }
        }
        Toast.makeText(getApplicationContext(), controlo.substring(2,controlo.length()-2), Toast.LENGTH_SHORT).show();
        atualizar();
    }

    public void click_depositar(View v) {
        JSONarrayDownloader downloa = new JSONarrayDownloader();
        JSONArray utiObj = new JSONArray();
        String controlo = "";
/*
        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/banco/confirma_trasacao/"+utilizador.get(0).toString()+"/"+utilizador.get(1).toString()+"/"+utilizador.get(2).toString()+"/"+a5.getText().toString()).get();
        } catch (ExecutionException | InterruptedException e) { e.printStackTrace();       utiObj = null; }

        if (utiObj != null) {
            controlo = utiObj.toString();
            if(controlo.substring(2,controlo.length()-2).equals("tem"))
            {
                downloa = new JSONarrayDownloader();
                utiObj = new JSONArray();

 */
                try {
                    utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/banco/levantar/"+utilizador.get(0).toString()+"/"+utilizador.get(1).toString()+"/"+utilizador.get(2).toString()+"/"+a5.getText().toString()).get();
                } catch (ExecutionException | InterruptedException e) {e.printStackTrace(); utiObj = null;}

                if (utiObj != null) {
                    controlo = utiObj.toString();
                    if(controlo.substring(2,controlo.length()-2).equals("levantado"))
                    {
                        downloa = new JSONarrayDownloader();
                        utiObj = new JSONArray();
                        try {
                            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/depositar/"+dados.get(0).get(0).toString()+"/"+dados.get(0).get(2).toString()+"/"+a5.getText().toString()).get();
                        } catch (ExecutionException | InterruptedException e) {e.printStackTrace(); }

                        if (utiObj != null) {
                            controlo = utiObj.toString();
                            if(controlo.substring(2,controlo.length()-2).equals("depositado"))
                            {
                                controlo="  depositado na sua conta  ";
                            }
                        }
                    }
                }/*
            }

        }
        */
        Toast.makeText(getApplicationContext(), controlo.substring(2,controlo.length()-2), Toast.LENGTH_SHORT).show();
        atualizar();
    }

}