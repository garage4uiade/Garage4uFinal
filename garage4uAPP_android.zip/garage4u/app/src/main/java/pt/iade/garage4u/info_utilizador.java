package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.JSONarrayDownloader;

public class info_utilizador extends AppCompatActivity {

    boolean click=false;
    Button button;
    EditText a1;
    EditText a2;
    EditText a3;
    EditText a4;

    public ArrayList<ArrayList<String>> dados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_utilizador);

        Intent getIntent = getIntent();
        dados =(ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
        String email=dados.get(0).get(0);
        String pass=dados.get(0).get(2);

        button = (Button) findViewById(R.id.RegButton2);
        a1=findViewById(R.id.editTextTextPersonName);
        a2=findViewById(R.id.editTextTextPersonMorada);
        a3=findViewById(R.id.editTextDate);
        a4=findViewById(R.id.editTextNumberDecimal);

        atualizar();
    }

    public void atualizar(){
        String email=dados.get(0).get(0);
        String pass=dados.get(0).get(2);

        JSONArray utiObj;
        JSONarrayDownloader obj = new JSONarrayDownloader();
        JSONObject utiObj2;
        ArrayList utilizador = new ArrayList();

        try {
            utiObj = obj.execute("https://garage4u-bd.herokuapp.com/api/querys/utilizador_info/"+email+"/"+pass).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
            utiObj = null;
        }
        if (utiObj != null) {
            try {
                utiObj2 = utiObj.getJSONObject(0);
                utilizador.add(utiObj2.getString("utilizadorName"));
                utilizador.add(utiObj2.getString("utilizadorMorada"));
                utilizador.add(utiObj2.getString("utilizadorBdate"));
                utilizador.add(utiObj2.getString("utilizadorIdentificacaoId"));
            } catch (JSONException e) {
                e.printStackTrace();
            }
            a1.setText(utilizador.get(0).toString());
            a2.setText(utilizador.get(1).toString());
            a3.setText(utilizador.get(2).toString());
            a4.setText(utilizador.get(3).toString());
            //Intent mainActivity = new Intent(getApplicationContext(), MainActivity.class);
            //mainActivity.putExtra("dados",dados);
            //startActivity(mainActivity);
        }
    }

    public void click_voltar(View v) {
        Intent mainActivity=new Intent();
        String windows = dados.get(1).get(dados.get(1).size()-1);

        switch (windows){
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(),cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
            case "Reservas":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "carteira":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "esqueci":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "Reserva":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
        }
        dados.get(1).remove(dados.get(1).size()-1);
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }

    public void click_carteira(View v) {
        dados.get(1).add("info_util");
        Intent mainActivity = new Intent(getApplicationContext(), carteira.class);
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }

    public void click_confirma(View v) {

        if(click == false){
            button.setText("confirmar");
            a1.setEnabled(true);
            a2.setEnabled(true);
            a3.setEnabled(true);
            a4.setEnabled(true);
            click = true;
        }
        else {
            JSONarrayDownloader downloa = new JSONarrayDownloader();
            JSONArray utiObj;
            String controlo="";

            String email=dados.get(0).get(0);
            String pass=dados.get(0).get(2);
            String nome=a1.getText().toString();
            String morada=a2.getText().toString();
            String data=a3.getText().toString();
            String identificacao=a4.getText().toString();


            try {
                utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/utilizador_update_dados/" + email + "/" + pass+ "/" +nome+ "/" +morada+ "/" +data+ "/" +identificacao).get();
            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
                utiObj = null;
            }
            if (utiObj != null) {
                controlo = utiObj.toString();
                controlo = controlo.substring(2,controlo.length()-2);
                Toast.makeText(getApplicationContext(), controlo, Toast.LENGTH_SHORT).show();
            }
            atualizar();
        }
    }
}