package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import pt.iade.garage4u.Downloader.PostData;

public class rate extends AppCompatActivity {

    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;

    public ArrayList<ArrayList<String>> dados;
    int rate = 0;
    String idResGar="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);
        button1 = (Button) findViewById(R.id.rate_1);
        button2 = (Button) findViewById(R.id.rate_2);
        button3 = (Button) findViewById(R.id.rate_3);
        button4 = (Button) findViewById(R.id.rate_4);
        button5 = (Button) findViewById(R.id.rate_5);
        Intent getIntent = getIntent();
        dados =(ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");

        int color = Color.parseColor("#99cc00");
        button1.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button2.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button3.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button4.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button5.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));

        idResGar="1";
        // ir buscar a bd o regar associado a reserva

    }

    public void click_voltar(View v) {
        Intent mainActivity=new Intent();
        String windows = dados.get(1).get(dados.get(1).size()-1);

        switch (windows){
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(),cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
            case "Reservas":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "carteira":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "esqueci":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "Reserva":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
        }
        dados.get(1).remove(dados.get(1).size()-1);
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }
    public void click_confirmar(View v) {
        Map<String, String> postData = new HashMap<>();
        postData.put("idResGar", idResGar);
        postData.put("rate",""+ rate);
        PostData task = new PostData(postData);
        task.execute("https://garage4u-bd.herokuapp.com/api/rate");
    }

    public void click_rate_1(View v) {
        button1.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), android.R.color.holo_orange_light));
        button2.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button3.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button4.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button5.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        rate = 1;
    }
    public void click_rate_2(View v) {
        button1.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button2.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), android.R.color.holo_orange_light));
        button3.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button4.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button5.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        rate = 2;
    }
    public void click_rate_3(View v) {
        button1.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button2.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button3.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), android.R.color.holo_orange_light));
        button4.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button5.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        rate = 3;
    }
    public void click_rate_4(View v) {
        button1.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button2.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button3.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button4.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), android.R.color.holo_orange_light));
        button5.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        rate = 4;
    }
    public void click_rate_5(View v) {
        button1.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button2.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button3.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button4.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), R.color.Grey));
        button5.setBackgroundTintList(ContextCompat.getColorStateList(getApplicationContext(), android.R.color.holo_orange_light));
        rate = 5;
    }
}