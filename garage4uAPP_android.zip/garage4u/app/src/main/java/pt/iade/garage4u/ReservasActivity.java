package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.JSONarrayDownloader;

public class ReservasActivity extends AppCompatActivity {

    public ArrayList<ArrayList<String>> dados;
    ArrayList garagens_disp;
    ListView lv1;
    int pos_garagem = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservas);
        final ListView list = findViewById(R.id.lista_jogadores);
        lv1 = (ListView) findViewById(R.id.lista_jogadores);
        Intent getIntent = getIntent();
        dados =(ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
        garagens_disp = new ArrayList();
        String[] garagens;
        JSONarrayDownloader downloa = new JSONarrayDownloader();
        JSONArray utiObj;
        JSONArray Obj;


        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/Reserva_garagens/" + dados.get(0).get(0) + "/" + dados.get(0).get(2)).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }

        if (utiObj != null) {
            try {
                if(utiObj.length() > 1) {
                //if(true) {
                    garagens = new String[utiObj.length()];
                    for (int num = 0; utiObj.length() > num; num++) {
                        Obj = utiObj.getJSONArray(num);
                        garagens[num] = Obj.get(0).toString();
                        String t2 = Obj.get(1).toString();
                        String t3 = Obj.get(2).toString();
                        garagens_disp.add(Obj.get(3).toString());
                    }
                    ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.lista_garagens, garagens);
                    lv1.setAdapter(adapter);
                }
                else
                {
                    ArrayList garagem = new ArrayList();
                    Obj = utiObj.getJSONArray(0);
                    garagem.add(Obj.get(3).toString());
                    dados.add(garagem);

                    Intent mainActivity = new Intent(getApplicationContext(), controlo.class);
                    mainActivity.putExtra("dados",dados);
                    startActivity(mainActivity);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String clickedItem=(String) list.getItemAtPosition(position);
                pos_garagem = position;
                Toast.makeText(ReservasActivity.this,"A garagem selecionada é a da rua: "+clickedItem,Toast.LENGTH_LONG).show();
            }
        });
    }

    public void click_selecionado(View v) {

        if(pos_garagem!=-1)
        {
            ArrayList garagem = new ArrayList();
            garagem.add(garagens_disp.get(pos_garagem));
            dados.add(garagem);
            dados.get(1).add("Reservas");

            Intent mainActivity = new Intent(getApplicationContext(), controlo.class);
            mainActivity.putExtra("dados",dados);
            startActivity(mainActivity);
        }
        else
        {
            Toast.makeText(ReservasActivity.this,"É necessario selecionar uma garagem",Toast.LENGTH_LONG).show();
        }
    }

    public void click_voltar(View v) {
        Intent mainActivity;
        String intent = dados.get(1).get(dados.get(1).size());

        switch (intent){
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(),cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
            case "Reservas":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "carteira":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "esqueci":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "Reserva":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
        }

        mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
        dados.get(1).remove(dados.get(1).size());
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }

    public void click_terminar(View v) {
        JSONarrayDownloader downloa = new JSONarrayDownloader();
        JSONArray utiObj;
        String controlo ="";
        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/termina_reserva/"+dados.get(0).get(0).toString()+"/"+dados.get(0).get(2).toString()+"/"+dados.get(2).get(0).toString()).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }

        if (utiObj != null) {
            controlo = utiObj.toString();
            controlo = controlo.substring(2,controlo.length()-2);
            Toast.makeText(getApplicationContext(), controlo, Toast.LENGTH_SHORT).show();

            Intent mainActivity = new Intent(getApplicationContext(), rate.class);
            mainActivity.putExtra("dados",dados);
            startActivity(mainActivity);
        }
    }




}

