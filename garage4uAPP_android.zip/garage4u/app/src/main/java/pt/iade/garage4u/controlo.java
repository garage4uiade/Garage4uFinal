package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import pt.iade.garage4u.Downloader.JSONarrayDownloader;
import pt.iade.garage4u.Downloader.JSONobjDownloader;

public class controlo extends AppCompatActivity {

    Button button_luz;
    Button button_porta1;
    Button button_porta2;
    Button button_terminar;
    public ArrayList<ArrayList<String>> dados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_controlo);

        Intent getIntent = getIntent();
        dados =(ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
        button_luz = (Button) findViewById(R.id.button_luz);
        button_porta1 = (Button) findViewById(R.id.button_porta1);
        button_porta2 = (Button) findViewById(R.id.button_porta2);
        button_terminar = (Button) findViewById(R.id.button9);
        button_terminar.setVisibility(View.INVISIBLE);
        JSONarrayDownloader downloa = new JSONarrayDownloader();
        JSONArray utiObj;
        JSONarrayDownloader downloa2 = new JSONarrayDownloader();
        JSONArray utiObj2;
        JSONObject Obj;
        String controlo="";
        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/controlo_tem_lampada/"+dados.get(2).get(0).toString()).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }
        if (utiObj != null) {
            controlo = utiObj.toString();
            controlo = controlo.substring(2,controlo.length()-2);

        }

        if(controlo.equals("tem lampada")) {comando_luz();}
        else {comando_sem_luz();}

        try {
            utiObj2 = downloa2.execute("https://garage4u-bd.herokuapp.com/api/querys/Reserva_garagens/" + dados.get(0).get(0) + "/" + dados.get(0).get(2)).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj2 = null;
        }

        if (utiObj2 != null) {
            if(utiObj2.length() == 1) {
                button_terminar.setVisibility(View.VISIBLE);
            }
        }



    }

    public void comando_luz() {
        button_luz.setVisibility(View.VISIBLE);
        button_porta1.setVisibility(View.VISIBLE);
        button_porta2.setVisibility(View.INVISIBLE);
    }

    public void comando_sem_luz() {
        button_luz.setVisibility(View.INVISIBLE);
        button_porta1.setVisibility(View.INVISIBLE);
        button_porta2.setVisibility(View.VISIBLE);
    }

    public void click_voltar(View v) {
        Intent mainActivity=new Intent();
        String windows = dados.get(1).get(dados.get(1).size()-1);

        switch (windows){
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(),cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
            case "Reservas":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "carteira":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "esqueci":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
            case "Reserva":
                mainActivity = new Intent(getApplicationContext(), ReservasActivity.class);
                break;
        }
        dados.get(1).remove(dados.get(1).size()-1);
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }

    public void click_luz(View v) {
        JSONarrayDownloader downloa = new JSONarrayDownloader();
        JSONArray utiObj;
        String controlo="";
        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/controlo_lampada/"+dados.get(0).get(0).toString()+"/"+dados.get(0).get(2).toString()+"/"+dados.get(2).get(0).toString()).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }
        if (utiObj != null) {
            controlo = utiObj.toString();
            controlo = controlo.substring(2,controlo.length()-2);
            Toast.makeText(getApplicationContext(), controlo, Toast.LENGTH_SHORT).show();
        }

    }

    public void click_porta(View v) {
        JSONarrayDownloader downloa = new JSONarrayDownloader();
        JSONArray utiObj;
        String controlo="";
        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/controlo_porta/"+dados.get(0).get(0).toString()+"/"+dados.get(0).get(2).toString()+"/"+dados.get(2).get(0).toString()).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }
        if (utiObj != null) {
            controlo = utiObj.toString();
            controlo = controlo.substring(2,controlo.length()-2);
            Toast.makeText(getApplicationContext(), controlo, Toast.LENGTH_SHORT).show();
        }
    }

    public void click_terminar(View v) {
        JSONarrayDownloader downloa = new JSONarrayDownloader();
        JSONArray utiObj;
        String controlo ="";
        try {
            utiObj = downloa.execute("https://garage4u-bd.herokuapp.com/api/querys/termina_reserva/"+dados.get(0).get(0).toString()+"/"+dados.get(0).get(2).toString()+"/"+dados.get(2).get(0).toString()).get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            utiObj = null;
        }

        if (utiObj != null) {
            controlo = utiObj.toString();
            controlo = controlo.substring(2,controlo.length()-2);
            Toast.makeText(getApplicationContext(), controlo, Toast.LENGTH_SHORT).show();

            Intent mainActivity = new Intent(getApplicationContext(), rate.class);
            mainActivity.putExtra("dados",dados);
            startActivity(mainActivity);
        }
    }

}