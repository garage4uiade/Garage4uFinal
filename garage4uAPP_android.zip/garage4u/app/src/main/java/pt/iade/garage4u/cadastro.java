package pt.iade.garage4u;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import org.json.JSONException;

import android.view.LayoutInflater;

import android.view.ViewGroup;


import pt.iade.garage4u.Downloader.GetPerson;
import pt.iade.garage4u.Downloader.PostData;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class cadastro extends AppCompatActivity {

    public ArrayList<ArrayList<String>> dados;
    EditText a1;
    EditText a2;
    EditText a3;
    EditText a4;
    EditText a5;
    EditText a6;
    RadioButton r1;
    RadioButton r2;
    RadioButton r3;
    Button cadastro;
    JSONArray user=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        Intent getIntent = getIntent();
        dados = (ArrayList<ArrayList<String>>) getIntent.getSerializableExtra("dados");
        a1 = findViewById(R.id.editTextTextPersonName);
        a2 = findViewById(R.id.editTextTextPersonMorada);
        a3 = findViewById(R.id.editTextDate);
        a4 = findViewById(R.id.editTextNumberDecimal);
        a5 = findViewById(R.id.txt_email2);
        a6 = findViewById(R.id.editTextTextPassword);
        r1 = findViewById(R.id.radioButton);
        r2 = findViewById(R.id.radioButton2);
        r3 = findViewById(R.id.radioButton3);
        cadastro = findViewById(R.id.RegButton);

        cadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GetPerson getPerson = new GetPerson();
                Intent i = new Intent(getApplicationContext(), log_in.class);
                try {
                    user = getPerson.execute("https://garage4u-bd.herokuapp.com/api/utilizador").get();
                    JSONObject aux = new JSONObject(user.get(0).toString());
                    String gender = "";
                    if (r1.isChecked()) {
                        gender = "m";
                    } else {
                        if (r1.isChecked()) {
                            gender = "f";
                        } else {
                            if (r1.isChecked()) {
                                gender = "o";
                            } else {
                                gender = "e";
                            }
                        }
                    }


                    Map<String, String> postData = new HashMap<>();
                    postData.put("nomeCartao","");
                    postData.put("cvv","");
                    postData.put("numCartao","");
                    postData.put("tipoDePagPerfCartao","False");
                    postData.put("quantidadeDinheiro", "0");
                    postData.put("utilizadorPass", a6.getText().toString());
                    postData.put("utilizadorEmail", a5.getText().toString());
                    postData.put("utilizadorIdentificacaoId", a4.getText().toString());
                    postData.put("utilizadorBdate", a3.getText().toString());
                    postData.put("utilizadorGender", gender);
                    postData.put("utilizadorMorada", a2.getText().toString());
                    postData.put("utilizadorName", a1.getText().toString());



                    PostData task = new PostData(postData);
                    task.execute("https://garage4u-bd.herokuapp.com/api/utilizador");


                    Toast.makeText(getApplicationContext(), "Utilizador criado com sucesso", Toast.LENGTH_SHORT).show();
                    Log.e("Signup", "" + postData.toString());
                    startActivity(i);
                } catch (Exception e) {
                    e.printStackTrace();
                    user = null;

                }
            }
        });
    }


    public void click_voltar(View v) {
        Intent mainActivity=new Intent();
        String windows = dados.get(1).get(dados.get(1).size()-1);

        switch (windows){
            case "login":
                mainActivity = new Intent(getApplicationContext(), log_in.class);
                break;
            case "maps":
                mainActivity = new Intent(getApplicationContext(), MapsActivity.class);
                break;
            case "cadastro":
                mainActivity = new Intent(getApplicationContext(),cadastro.class);
                break;
            case "info_util":
                mainActivity = new Intent(getApplicationContext(), info_utilizador.class);
                break;
            case "controlo":
                mainActivity = new Intent(getApplicationContext(), controlo.class);
                break;
        }
        dados.get(1).remove(dados.get(1).size()-1);
        mainActivity.putExtra("dados",dados);
        startActivity(mainActivity);
    }




}