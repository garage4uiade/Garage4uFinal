package pt.iade.garage4u.models.repositories;

import org.springframework.data.repository.CrudRepository;

import pt.iade.garage4u.models.Utilizador;

public interface UtilizadorRepository extends CrudRepository<Utilizador, Integer> {
}