package pt.iade.garage4u.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.garage4u.models.Esqueceu_pass;

public interface Esqueceu_passRepository extends CrudRepository<Esqueceu_pass, Integer> {
}