package pt.iade.garage4u.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.garage4u.models.Estado;

public interface EstadoRepository extends CrudRepository<Estado, Integer> {
}