package pt.iade.garage4u;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Garage4uApplication {

    public static void main(String[] args) {
        SpringApplication.run(Garage4uApplication.class, args);
    }
    // teste 
}
