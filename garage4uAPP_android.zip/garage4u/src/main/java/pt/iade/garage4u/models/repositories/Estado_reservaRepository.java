package pt.iade.garage4u.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.garage4u.models.Estado_reserva;

public interface Estado_reservaRepository extends CrudRepository<Estado_reserva, Integer> {
}