package pt.iade.garage4u.models.repositories;

import org.springframework.data.repository.CrudRepository;
import pt.iade.garage4u.models.Res_gar;

public interface Res_garRepository extends CrudRepository<Res_gar, Integer> {
}