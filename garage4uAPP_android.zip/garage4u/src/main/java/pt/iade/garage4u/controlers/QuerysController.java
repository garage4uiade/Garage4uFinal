package pt.iade.garage4u.controlers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import pt.iade.garage4u.models.Exceptions.Response;
import pt.iade.garage4u.models.Utilizador;
import pt.iade.garage4u.repository.QueryRepository;

import java.util.Optional;

@RestController
@RequestMapping(path = "/api/querys")
public class QuerysController {

    private final Logger logger = LoggerFactory.getLogger(QuerysController.class);

    @Autowired
    private QueryRepository queryRepository;

    @GetMapping(path = "/existe/{nome:[.-z]+}/{pass:[.-z]+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<String> getexit_userBypass_nome(@PathVariable("nome") String nome,@PathVariable("pass") String pass) {
        logger.info("Sending bio from route nome: ,pass:" + nome +pass);
        return queryRepository.Exite_utilizador(nome,pass);
    }

    @GetMapping(path = "/utilizador_info/{email:[.-z]+}/{pass:[.-z]+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<Utilizador> get_utilizador_info(@PathVariable("email") String email,@PathVariable("pass") String pass) {
        logger.info("Sending bio from route nome: ,pass:" + email +pass);
        return queryRepository.utilizador_info(email,pass);
    }

    @GetMapping(path = "/garagens_info/{id:[0-9]+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<String> get_garagens_info(@PathVariable("id") int id) {
        logger.info("Sending bio from route id:" + id);
        return queryRepository.garagens_info(id);
    }



    @GetMapping(path = "/cria_utilizador/{nome:[A-z]+}/{morada:[.-z]+}/{genero:[a-z]+}/{data:[.-z]+}/{identificacao:[0-9]+}/{email:[.-z]+}/{pass:[.-z]+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<String> get_cria_utilizador(@PathVariable("nome") String nome,@PathVariable("morada") String morada,@PathVariable("genero") char genero,@PathVariable("data") String data,@PathVariable("identificacao") int identificacao,@PathVariable("email") String email,@PathVariable("pass") String pass) {
        logger.info("Sending bio from route nome:,morada:,genero:,data:,identificacao:,email:,pass:" +nome+morada+genero+data+identificacao+email+pass);
        return queryRepository.cria_utilizador(nome,morada,genero,data,identificacao,email,pass);
    }


    @GetMapping(path = "/utilizador_reservas/{nome:[.-z]+}/{pass:[.-z]+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<String> getutilizador_reservas(@PathVariable("nome") String nome,@PathVariable("pass") String pass) {
        logger.info("Sending bio from route nome: ,pass:" + nome +pass);
        return queryRepository.utilizador_reserva(nome,pass);
    }

    @GetMapping(path = "/adicionar_garagens/{utilizador_email:[.-z]+}/{utilizador_pass:[.-z]+}/{garagem_localizacao:[0-z]+}/{garagem_zona:[a-z]+}/{garagem_zona_cod:[0-9]+}/{garagem_lampada:[0-1]+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<String> get_Add_garagens(@PathVariable("utilizador_email") String utilizador_email,@PathVariable("utilizador_pass") String utilizador_pass,@PathVariable("garagem_localizacao") String garagem_localizacao,@PathVariable("garagem_zona") String garagem_zona,@PathVariable("garagem_zona_cod") int garagem_zona_cod,@PathVariable("garagem_lampada") boolean garagem_lampada) {
        logger.info("Sending bio from route utilizador_email:,utilizador_pass:,garagem_localizacao:,garagem_zona:,garagem_zona_cod:,garagem_lampada:" + utilizador_email+utilizador_pass+garagem_localizacao+garagem_zona+garagem_zona_cod+garagem_lampada);
        return queryRepository.add_garagens(utilizador_email,utilizador_pass,garagem_localizacao,garagem_zona,garagem_zona_cod,garagem_lampada);
    }
  



    // banco
    @GetMapping(path = "/banco/depositar/{utilizador:[A-z]+}/{num_card:[0-9]+}/{cvv:[0-9]+}/{quantidade_dinheiro:[0-9]+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<String> getdepositar(@PathVariable("utilizador") String utilizador,@PathVariable("num_card") int num_card,@PathVariable("cvv") int cvv,@PathVariable("quantidade_dinheiro") int quantidade_dinheiro) {
        logger.info("Sending bio from route utilizador: ,num_card:,cvv:,quantidade_dinheiro:" + utilizador +num_card+cvv+quantidade_dinheiro);
        return queryRepository.deposita(utilizador ,num_card,cvv,quantidade_dinheiro);
    }

    @GetMapping(path = "/banco/levantar/{utilizador:[A-z]+}/{num_card:[0-9]+}/{cvv:[0-9]+}/{quantidade_dinheiro:[0-9]+}", produces = MediaType.APPLICATION_JSON_VALUE)
    public Iterable<String> getlevantar(@PathVariable("utilizador") String utilizador,@PathVariable("num_card") int num_card,@PathVariable("cvv") int cvv,@PathVariable("quantidade_dinheiro") int quantidade_dinheiro) {
        logger.info("Sending bio from route utilizador: ,num_card:,cvv:,quantidade_dinheiro:" + utilizador +num_card+cvv+quantidade_dinheiro);
        return queryRepository.levanta(utilizador ,num_card,cvv,quantidade_dinheiro);
    }
}




